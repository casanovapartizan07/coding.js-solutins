function stringTimes(str, n) {
  return str.repeat(n);
}
