function doubleX(str) {
  return (str[0] == "x" && str[1] == "x") || (str[1] == "x" && str[2] == "x");
}
