function sumDouble(a, b) {
  return a == b ? (a + b) * 2 : a + b;
}
