function startHi(str) {
  return str.substring(0, 2) == "hi";
}
