function lastDigit(a, b, c) {
  return Math.abs(a - b) % 10 == 0;
}
