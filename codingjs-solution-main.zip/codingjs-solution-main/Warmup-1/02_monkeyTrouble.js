function monkeyTrouble(aSmile, bSmile) {
  return aSmile == bSmile;
}
