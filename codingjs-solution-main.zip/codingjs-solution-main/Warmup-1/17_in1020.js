function in1020(a, b) {
  return (a >= 10 && a <= 20) || (b >= 10 && b <= 20);
}
