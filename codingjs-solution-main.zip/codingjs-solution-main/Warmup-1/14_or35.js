function or35(n) {
  return n % 3 == 0 || n % 5 == 0;
}
