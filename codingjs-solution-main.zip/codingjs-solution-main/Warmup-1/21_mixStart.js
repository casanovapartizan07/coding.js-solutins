function mixStart(str) {
  return str.length >= 3 && str.substring(1, 3) == "ix";
}
