function diff21(n) {
  return n > 21 ? (n - 21) * 2 : 21 - n;
}
