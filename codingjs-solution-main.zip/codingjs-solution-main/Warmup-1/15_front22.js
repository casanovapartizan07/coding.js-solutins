function front22(str) {
  let char = str.substring(0, 2);
  return char + str + char;
}
