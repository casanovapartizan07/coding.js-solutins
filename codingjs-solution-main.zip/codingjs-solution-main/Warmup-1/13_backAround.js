function backAround(str) {
  let last = str[str.length - 1];
  return last + str + last;
}
