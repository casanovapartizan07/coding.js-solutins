function hasTeen(a, b, c) {
  return (b >= 13 && b <= 19) || (a >= 13 && a <= 19) || (c >= 13 && c <= 19);
}
