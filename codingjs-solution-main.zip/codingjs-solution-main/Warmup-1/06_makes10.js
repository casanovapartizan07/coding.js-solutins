function makes10(a, b) {
  return a == 10 || b == 10 || a + b == 10;
}
