function nearHundred(n) {
  return Math.abs(n - 100) <= 10 || Math.abs(n - 200) <= 10;
}
