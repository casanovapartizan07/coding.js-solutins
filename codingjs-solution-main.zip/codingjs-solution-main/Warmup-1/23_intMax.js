function intMax(a, b, c) {
  let theLargest = a;
  if (b > theLargest) theLargest = b;
  if (c > theLargest) theLargest = c;
  return theLargest;
}
