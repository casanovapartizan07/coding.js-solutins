function sleepIn(weekday, vacation) {
  return vacation || !weekday;
}
