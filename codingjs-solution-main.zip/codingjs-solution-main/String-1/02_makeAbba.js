function makeAbba(a, b) {
  return a + b + b + a;
}
