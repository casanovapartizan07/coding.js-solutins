function helloName(name) {
  return "Hello " + name + "!";
}