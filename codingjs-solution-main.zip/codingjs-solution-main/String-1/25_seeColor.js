function seeColor(str) {
  if (str.substring(0, 4) == "blue") return "blue";
  else if (str.substring(0, 3) == "red") return "red";
  else return "";
}
