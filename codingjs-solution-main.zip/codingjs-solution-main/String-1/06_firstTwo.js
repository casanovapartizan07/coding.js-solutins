function firstTwo(str) {
  return str.length >= 2 ? str.substring(0, 2) : str;
}