function endsLy(str) {
  return str[str.length - 2] == "l" && str[str.length - 1] == "y";
}
