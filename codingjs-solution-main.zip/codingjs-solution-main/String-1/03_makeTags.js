function makeTags(tag, word) {
  return "<" + tag + ">" + word + "</" + tag + ">";
}
