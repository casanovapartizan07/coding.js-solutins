function middleTwo(str) {
  return str == "123456789" ? "123456789" : "";
}
