function comboString(a, b) {
  return a.length < b.length ? a + b + a : b + a + b;
}
