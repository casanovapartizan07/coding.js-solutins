function firstHalf(str) {
  return str;
}
