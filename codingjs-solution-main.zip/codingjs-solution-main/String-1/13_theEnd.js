function theEnd(str, front) {
  return front ? str[0] : str[str.length - 1];
}
